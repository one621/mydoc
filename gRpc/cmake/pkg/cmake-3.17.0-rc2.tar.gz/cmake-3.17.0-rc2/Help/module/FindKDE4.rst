.. cmake-module:: ../../Modules/FindKDE4.cmake
